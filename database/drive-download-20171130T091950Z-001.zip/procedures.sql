
/*PROCEDURE for Adding of senator*/

delimiter //
CREATE PROCEDURE insertnewSenator (
	legislatorType VARCHAR(15),
	firstName VARCHAR(64), 
	middleInitial VARCHAR(64), 
	lastName VARCHAR(64), 
	office VARCHAR(64),	
	senatePosition VARCHAR(64),
	directLine VARCHAR(20), 
	trunkLine VARCHAR(20), 
	email VARCHAR(64), 
	website VARCHAR(64)
)
BEGIN
	declare id int; 
	INSERT INTO Legislator (
		legislatorType, 
		firstName, 
		middleInitial, 
		lastName
	) 
	values (
		legislatorType, 
		firstName, 
		middleInitial, 
		lastName
	);
	select legislatorId into id from Legislator L 
		where L.firstName = firstName and L.middleInitial = middleInitial and L.lastName = lastName;
	INSERT INTO Senator
	values (
		id, 
		office, 
		senatePosition, 
		directLine, 
		trunkLine, 
		email, 
		website
	);
END//
delimiter ; 

/*PROCEDURE for Adding of House Member*/
delimiter //
CREATE PROCEDURE insertnewHouseMember (
	legislatorType VARCHAR(15),
	firstName VARCHAR(64),
	middleInitial VARCHAR(64),
	lastName VARCHAR(64),
	office VARCHAR(64),
	province VARCHAR(64),
	district VARCHAR(64),
	directLine VARCHAR(20),
	phoneNo VARCHAR(20)
)
BEGIN
	declare id int; 
	INSERT INTO Legislator (
		legislatorType,
		firstName, 
		middleInitial, 
		lastName
	) 
	values (
		legislatorType, 
		firstName, 
		middleInitial, 
		lastName
	);
	select legislatorId into id from Legislator L 
		where L.firstName = firstName and L.middleInitial = middleInitial and L.lastName = lastName;
	INSERT INTO HouseMember
	values (
		id, 
		office, 
		province,
		district,
		directLine,
		phoneNo
	);
END//
delimiter ; 


/*Procedure for Adding Bill*/
/*
1. get information of the bill
2. check if the Author Exist in the Data
3. check if correct yung gumagawa ng biill
	eg. kung senator -> senate bill
		if house member -> house bill
requirements before calling the procedure
*/
delimiter //
CREATE PROCEDURE insertnewBill (
	billType VARCHAR(5),
	title VARCHAR(256),
	dateFiled VARCHAR(64),
	longTitle VARCHAR(999),
	scope VARCHAR(64),
	
	firstName VARCHAR(64),
	middleInitial VARCHAR(64),
	lastName VARCHAR(64),

	firstReading VARCHAR(64),
	secondReading VARCHAR(64),
	thirdReading VARCHAR(64)
)
BEGIN
	declare no int; 

	INSERT INTO Bill (
		billType,
		title,
		dateFiled,
		longTitle,
		scope,
		firstName,
		middleInitial,
		lastName
	) 
	values (
		billType,
		title,
		str_to_date(dateFiled, "%M %d, %Y"),
		longTitle,
		scope,
		firstName,
		middleInitial,
		lastName
	);

	select billNo into no from Bill B 
		where B.title = title and B.dateFiled = str_to_date(dateFiled, "%M %d, %Y");

	INSERT INTO BillStatus
	values (
		no,
		firstReading,
		secondReading,
		thirdReading
	);
END//
delimiter ; 


/*UPDATE*/

/*DELETE*/

/*SEARCH*/







