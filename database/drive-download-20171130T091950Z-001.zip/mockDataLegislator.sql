call insertnewSenator('Senator', 'Aquilino', 'dl L', 'Pimentel', 
	'Pasay City', 'President', '822 97 58', '455 32 21', 'kokopimentel@gmail.com', 'legislator1.org');

call insertnewSenator('Senator', 'Ralph', 'G', 'Recto', 
	'Pasay City', 'Pro-Tempore', '637 56 57', '455 32 21', 'legislator2@gmail.com', 'legislator2.org');

call insertnewHouseMember('House Member', 'Abad', 'R', 'Henedina', 
	'Quezon City', 'Batanes', 'Lone', '9315320', '931 50 01');

call insertnewSenator('Senator', 'Vicente', 'C', 'Sotto', 
	'Pasay City', 'Minority Leader', '637 56 57', '455 32 21', 'legislator4@gmail.com', 'legislator4.org');

call insertnewHouseMember('House Member', 'Francis Gerald', 'A', 'Abaya', 
	'Quezon City', 'Cavite', '1st', '9316381', '931 50 01');


call insertnewHouseMember('House Member', 'Raneo', 'E', 'Abu', 
	'Quezon City', 'Batangas', '2nd', '9315239', '931 50 01');

call insertnewSenator('Senator', 'Franklin', 'M', 'Drilon', 
	'Pasay City', 'Minority Leader', '637 56 57', '455 32 21', 'legislator4@gmail.com', 'legislator4.org');

call insertnewSenator('Senator', 'Sonny', 'M', 'Angara', 
	'Pasay City', 'Assistant Minority Leader', '637 56 57', '455 32 21', 'legislator5@gmail.com', 'legislator5.org');

call insertnewHouseMember('House Member', 'Rodrigo', 'A', 'Abellanosa', 
	'Quezon City', 'Cebu', '2nd', '9315239', '931 50 01');

call insertnewSenator('Senator', 'Paolo Benigno', 'V', 'Aquino', 
	'Pasay City', 'Minority Leader', '637 56 57', '455 32 21', 'legislator4@gmail.com', 'legislator4.org');




